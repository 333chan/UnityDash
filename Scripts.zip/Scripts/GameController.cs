﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GameController : MonoBehaviour
{
    public UnityPlayer unityChan;
    public Text scoreText;
    public LifePanel lifePanel;

    // Update is called once per frame
    public void Update()
    {
        // スコア更新
        int score = CalcScore();
        if (score <= 9999)
        {
            scoreText.text = "Score : " + score + "m"; ;

        }
        else
        {
            scoreText.text = "Score : " + 9999 + "m"; ;
        }



        // ライフパネルの更新
        lifePanel.UpdateLife(unityChan.Life());
    }

    int CalcScore()
    {
        // プレイヤーの走行距離をスコアに
        return (int)unityChan.transform.position.z;
    }
}
