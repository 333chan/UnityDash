﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class ChangeGameover : MonoBehaviour
{
    public FadeController fade;
    public AutoStage1 stage;
    int c = 0;

    void Awake()
    {
        Object.DontDestroyOnLoad(this);
    }

    void Start()
    {

    }

    void Update()
    {
        if (false)
        {

            if (c == 0)
            {
                SceneManager.LoadScene("Gameover");
                c = 1;
            }

            
        }
    }
}
