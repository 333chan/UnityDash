﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LoadObject : MonoBehaviour
{
    // Start is called before the first frame update
    //void Start()
    //{
    //    Debug.Log("呼び出し");
    //    Debug.Log(GameObject.Find("DontDestroyGameObject").GetComponent<UnityPlayer>().dontDestroyString);
    //}
}
